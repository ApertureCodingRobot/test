#version 150

in vec2 texCoord;
out vec4 fragColor;

void main() {
    fragColor = vec4(1.0); // Pure white, max brightness, no tint
}
